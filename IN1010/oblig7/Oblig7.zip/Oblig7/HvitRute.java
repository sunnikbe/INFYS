class HvitRute extends Rute{

    public HvitRute(int r, int k, Labyrint lab){
        super(r, k, lab);
    }

    @Override
    public String toString(){
        return "   ";
    }
}