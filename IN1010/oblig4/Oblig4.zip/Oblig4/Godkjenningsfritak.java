interface Godkjenningsfritak {
    String hentKontrollkode();
}