class Vanlig extends Legemiddel{
    
    public Vanlig(String n, int p, double v){
        super(n, p, v);
    }
}
